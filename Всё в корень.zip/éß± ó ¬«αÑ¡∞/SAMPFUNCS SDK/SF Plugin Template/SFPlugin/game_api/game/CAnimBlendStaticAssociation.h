/*****************************************************************************
*
*  PROJECT:     Multi Theft Auto v1.0
*  LICENSE:     See LICENSE in the top level directory
*  FILE:        sdk/game/CAnimBlendStaticAssocation.h
*  PURPOSE:     Animation blend static association interface
*
*  Multi Theft Auto is available from http://www.multitheftauto.com/
*
*****************************************************************************/

#ifndef __CAnimBlendStaticAssociation_H
#define __CAnimBlendStaticAssociation_H

class CAnimBlendStaticAssociation
{
public:
};

#endif
